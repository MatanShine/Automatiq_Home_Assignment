import sqlite3

DB_PATH = "employees.db"

def fetch_employees(conn):
    raise NotImplementedError


def fetch_columns(conn):
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info(employees)")
    return cursor.fetchall()

def main():
    with sqlite3.connect(DB_PATH) as conn:
        employees = fetch_employees(conn)
        columns = fetch_columns(conn)
        print("Employees:")
        print(employees)
        print("Columns:")
        print(columns)

if __name__ == "__main__":
    main()